# Course notes

Create one Markdown file per course, e.g. `CMPT_120.md` or `MACM_101.md`.

Suggested template:

## Week / topic
- Main concepts:
- Definitions / formulas:
- Example problems:
- Questions I still have:
- Next practice task:
